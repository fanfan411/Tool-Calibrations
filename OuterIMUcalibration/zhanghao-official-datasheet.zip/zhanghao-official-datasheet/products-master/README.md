![](img/logo.png)

## 软件及文档下载

[繁體中文](https://github.com/hipnuc/products/tree/tc) |

------


本公司持续维护、更新产品与软件，为用户提供更良好的使用体验与功能。本中心包含了所有产品资料，包含文档、驱动程序，并且提供开源例程与姿态记录软件。

| 文件夹           | 说明               |
| ---------------- | ------------------ |
| doc              | 产品用户手册       |
| examples         | 接收程序示例及源码 |
| hardware         | 硬件资料           |
| windows_pc_tools | 上位机             |
| usb_uart_drivers | 串口驱动程序       |


更多内容请访问：

> * 网站：www.hipnuc.com