C#例程请直接参考开源的超核Windows上位机: Uranus

https://github.com/hipnuc