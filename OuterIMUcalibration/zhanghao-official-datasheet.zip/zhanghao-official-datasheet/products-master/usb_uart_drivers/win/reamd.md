* HI226/HI229请安装CP2104.zip
* HI221请安装CH341SER
* CH110请安装PL2303_Prolific_DriverInstaller_v1200

